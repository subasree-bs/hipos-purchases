import React from 'react';
import './styles.css';
import {Box} from "@mui/material";
// #root{ padding: 10px; }
import { DatePicker } from 'rsuite';
import $ from "jquery";

export default function Datetimepick(){

$(function() {

  $('input[name="datefilter"]').daterangepicker({
      autoUpdateInput: false,
      locale: {
          cancelLabel: 'Clear'
      }
  });

  $('input[name="datefilter"]').on('apply.daterangepicker', function(ev, picker) {
      $(this).val(picker.startDate.format('MM/DD/YYYY') + ' - ' + picker.endDate.format('MM/DD/YYYY'));
  });

  $('input[name="datefilter"]').on('cancel.daterangepicker', function(ev, picker) {
      $(this).val('');
  });

});
  
    return(
      <Box>
            <br />
            <DatePicker
               format="yyyy-MM-dd HH:mm:ss"
               calendarDefaultDate={new Date('2022-02-02 00:00:00')}
               ranges={[
                 {
                   label: 'Now',
                   value: new Date()
                 }
               ]}
               style={{ width: 260 }}
             />
      </Box>
    );
}