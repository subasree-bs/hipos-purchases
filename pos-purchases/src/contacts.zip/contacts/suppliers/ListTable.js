import React, { useState } from "react";
import { Box,Paper, Grid, Table, TableBody, TableHead, TableContainer, TableRow, Button, Menu, Divider, MenuItem, TableFooter,Typography } from '@mui/material';
import { StyledTableRow, StyledTableCell} from '../../Table';
import $ from 'jquery';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import {FaFileCsv, FaPrint, FaFilePdf } from "react-icons/fa";
import { AiFillFileExcel } from "react-icons/ai";
import Customeredit from "./Edit";
import Customercreate from "./Create";
import { userStyle } from "../../PageStyle";

function Suppliertable() {

    // ***** Jquery Plugin ****//
    $(document).ready(function () {
        setTimeout(function () {
            $('#example').DataTable({
                language: { search: '', searchPlaceholder: "Search..." },
                lengthMenu: [25, 50, 100, 200, 500, 1000],
            });
        }, 1000);
    });
    
    //***** Action Button *****//
    const [anchorEl, setAnchorEl] = useState(null);
    const open = Boolean(anchorEl);
    const handleClick = (event) => { setAnchorEl(event.currentTarget); };
    const handleClose = () => { setAnchorEl(null); };

    return (
        <>
            <Box sx={userStyle.container} >
                { /* ****** Header Content ****** */ }
                   <Grid container spacing={2}>
                       <Grid item xs={8}>
                          <Typography  sx={userStyle.importheadtext}>All your Suppliers</Typography>
                       </Grid>
                       <Grid item xs={4}>
                          <Customercreate />
                       </Grid>
                    </Grid><br />
                    { /* ****** Header Buttons ****** */ }
                    <Grid container sx={{ justifyContent: "center",}} >
                        <Grid>
                            <Button sx={userStyle.buttongrp} variant="outlined">
                              <FaFileCsv />&ensp;Export to CSV
                            </Button>
                            <Button sx={userStyle.buttongrp} variant="outlined">
                              <AiFillFileExcel />&ensp;Export to Excel
                            </Button>
                            <Button sx={userStyle.buttongrp} variant="outlined">
                              <FaPrint />&ensp;Print
                            </Button>
                            <Button sx={userStyle.buttongrp} variant="outlined">
                              <FaFilePdf />&ensp;Export to PDF
                            </Button>
                        </Grid>
                        {/* ****** Table Grid Container ****** */}
                        <Grid container>
                           <Grid md={4} sm={2} xs={1}></Grid>
                           <Grid md={8} sm={10} xs={10} sx={{ align: "center" }}></Grid>
                        </Grid>
                    </Grid><br />
                    { /* ****** Table start ****** */ }
                   <TableContainer component={Paper} >
                       <Table sx={{}} aria-label="simple table" id="example">
                        <TableHead sx={{ fontWeight: "600"}} >
                            <StyledTableRow >
                                <StyledTableCell>Actions</StyledTableCell>
                                <StyledTableCell>Contact ID</StyledTableCell>
                                <StyledTableCell>Business Name</StyledTableCell>
                                <StyledTableCell>Name</StyledTableCell>
                                <StyledTableCell>Email</StyledTableCell>
                                <StyledTableCell>Tax Number</StyledTableCell>
                                <StyledTableCell>Pay Term</StyledTableCell>
                                <StyledTableCell>Opening Balance</StyledTableCell>
                                <StyledTableCell>Advance Balance</StyledTableCell>
                                <StyledTableCell>Added On</StyledTableCell>
                                <StyledTableCell>Address</StyledTableCell>
                                <StyledTableCell>Mobile</StyledTableCell>
                                <StyledTableCell>Total Purchase Due</StyledTableCell>
                                <StyledTableCell>Total Purchase Return Due</StyledTableCell>
                                <StyledTableCell>Custom Field 1</StyledTableCell>
                                <StyledTableCell>Custom Field 2</StyledTableCell>
                                <StyledTableCell>Custom Field 3</StyledTableCell>
                                <StyledTableCell>Custom Field 4</StyledTableCell>
                                <StyledTableCell>Custom Field 5</StyledTableCell>
                                <StyledTableCell>Custom Field 6</StyledTableCell>
                                <StyledTableCell>Custom Field 7</StyledTableCell>
                                <StyledTableCell>Custom Field 8</StyledTableCell>
                                <StyledTableCell>Custom Field 9</StyledTableCell>
                                <StyledTableCell>Custom Field 10</StyledTableCell>
                            </StyledTableRow>
                        </TableHead>
                        <TableBody>
                            <StyledTableRow>
                                <StyledTableCell component="th" scope="row" colSpan={1}>
                                        <>
                                            <Button
                                                id="demo-customized-button"
                                                aria-controls={open ? 'demo-customized-menu' : undefined}
                                                aria-haspopup="true"
                                                aria-expanded={open ? 'true' : undefined}
                                                variant="contained"
                                                disableElevation
                                                onClick={handleClick}
                                                endIcon={<KeyboardArrowDownIcon />}
                                                size="small"
                                                sx={{backgroundColor: '#6420c0', textTransform: 'Capitalize'}} >
                                                Actions
                                            </Button>
                                            <Menu
                                                id="demo-customized-menu"
                                                MenuListProps={{
                                                    'aria-labelledby': 'demo-customized-button',
                                                }}
                                                anchorEl={anchorEl}
                                                open={open}
                                                onClose={handleClose}
                                            >
                                                <Customeredit />
                                                <MenuItem onClick={handleClose} disableRipple><DeleteIcon />&ensp;Delete</MenuItem>
                                                <MenuItem onClick={handleClose} disableRipple><PictureAsPdfIcon />&ensp;PDF</MenuItem>
                                            </Menu>
                                        </>
                                    </StyledTableCell>
                                    <StyledTableCell align="left">CI0001</StyledTableCell>
                                    <StyledTableCell align="left">TEST</StyledTableCell>
                                    <StyledTableCell align="left">Admin</StyledTableCell >
                                    <StyledTableCell align="left">admin@gmail.com</StyledTableCell>
                                    <StyledTableCell align="left">CAI001</StyledTableCell>
                                    <StyledTableCell align="left">0.00</StyledTableCell>
                                    <StyledTableCell align="left">CASH</StyledTableCell>
                                    <StyledTableCell align="left">0.00</StyledTableCell>
                                    <StyledTableCell align="left">0.00</StyledTableCell>
                                    <StyledTableCell align="left">24/08/2022</StyledTableCell>
                                    <StyledTableCell align="left">TEST</StyledTableCell>
                                    <StyledTableCell align="left">TEST</StyledTableCell>
                                    <StyledTableCell align="left">TEST</StyledTableCell>
                                    <StyledTableCell align="left">TEST</StyledTableCell>
                                    <StyledTableCell align="left">TEST</StyledTableCell>
                                    <StyledTableCell align="left">TEST</StyledTableCell>
                                    <StyledTableCell align="left">TEST</StyledTableCell>
                                    <StyledTableCell align="left">TEST</StyledTableCell>
                                    <StyledTableCell align="left">TEST</StyledTableCell>
                                    <StyledTableCell align="left">TEST</StyledTableCell>
                                    <StyledTableCell align="left">TEST</StyledTableCell>
                                    <StyledTableCell align="left">TEST</StyledTableCell>
                                    <StyledTableCell align="left">TEST</StyledTableCell>
                                </StyledTableRow>
                        </TableBody>
                        { /* ****** Table Footer Start ****** */ }
                        <TableFooter sx={{backgroundColor: '#9591914f', height: '75px'}}>
                            <TableRow className="table2_total" >
                                <StyledTableCell align="left"></StyledTableCell>
                                <StyledTableCell align="left"></StyledTableCell>
                                <StyledTableCell align="left"></StyledTableCell>
                                <StyledTableCell align="left"></StyledTableCell>
                                <StyledTableCell align="left"></StyledTableCell>
                                <StyledTableCell align="left"></StyledTableCell>
                                <StyledTableCell colSpan={8} sx={{color: 'black', fontSize: '20px', justifyContent: 'center'}}>Total: 0.0</StyledTableCell>
                                <StyledTableCell align="left" sx={{color: 'black', fontSize: '16px'}}>0.00</StyledTableCell>
                                <StyledTableCell align="left" sx={{color: 'black', fontSize: '16px'}}>0.00</StyledTableCell>
                                <StyledTableCell align="left"></StyledTableCell>
                                <StyledTableCell align="left"></StyledTableCell>
                                <StyledTableCell align="left"></StyledTableCell>
                                <StyledTableCell align="left"></StyledTableCell>
                                <StyledTableCell align="left"></StyledTableCell>
                                <StyledTableCell align="left"></StyledTableCell>
                                <StyledTableCell align="left"></StyledTableCell>
                                <StyledTableCell align="left"></StyledTableCell>
                            </TableRow>
                        </TableFooter>
                        { /* ****** Table Footer End ****** */ }
                    </Table>
                </TableContainer>
                { /* ****** Table End ****** */ }
            </Box>
        </>
    );
}
export default Suppliertable;